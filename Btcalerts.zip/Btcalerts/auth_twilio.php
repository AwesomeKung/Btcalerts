<?php

// Live
$account_sid = '';
$auth_token = '';

// // Dev (TEST)
// $account_sid = '';
// $auth_token = '';

?>