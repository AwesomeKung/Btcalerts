<?php

// CMC Live
$cmc_pro_api_key = "";

// CMC Dev
// $cmc_pro_api_key = "";

?>